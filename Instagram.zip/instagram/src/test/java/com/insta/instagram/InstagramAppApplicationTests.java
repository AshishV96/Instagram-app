package com.insta.instagram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstagramAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
