package com.insta.instagram.exceptions;

public class PostException extends Exception {

    public PostException(String message){
        super(message);
    }

}
