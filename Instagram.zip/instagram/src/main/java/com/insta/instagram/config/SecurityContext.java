package com.insta.instagram.config;

public class SecurityContext {

    public static final String JWT_KEY = "voperuihjdfbhwevrhvzierkmnerebmweoirunezokoidrenizhjeb";
    public static final String HEADER = "Authorization";

}
